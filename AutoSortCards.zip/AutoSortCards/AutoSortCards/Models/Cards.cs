﻿namespace AutoSortCards.Models
{
    public class Cards
    {
       public int id { get; set; }
        public string value { get; set; }

        public string color { get; set; }
    }
}
