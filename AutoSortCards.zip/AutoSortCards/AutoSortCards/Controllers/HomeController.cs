﻿using AutoSortCards.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net.Http.Json;
using System.Text;

namespace AutoSortCards.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        string Baseurl = "https://cardpriorityapi.azurewebsites.net/api/";


        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<Cards> ls = new List<Cards>();
            ViewData["currentview"] = "shuffle";
            return View(ls);
        }

        public ActionResult Shuffle()
        {

            List<Cards> CardInfo = new List<Cards>();
            
            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                    //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                var responseTask =  client.GetAsync("Card");
                responseTask.Wait();

                var result = responseTask.Result;
                //Checking the response is successful or not which is sent using HttpClient  
                if (result.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var readTask = result.Content.ReadAsAsync<IList<Cards>>();

                    readTask.Wait();

                    CardInfo = readTask.Result.ToList();

                }
                //returning the employee list to view  
               // return View(EmpInfo);
            }
            ViewData["currentview"] = "shuffle";
            return View("Index", CardInfo);

           
        }
        public static List<t> GetRandomElements<t>(IEnumerable<t> list, int elementsCount)
        {
            return list.OrderBy(x => Guid.NewGuid()).Take(elementsCount).ToList();
        }

        public IActionResult SorttheCards(List<Cards> lsCards)
        {

            List<Cards> CardInfo = new List<Cards>();

            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //Define request data format  
                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                StringContent content = new StringContent(JsonConvert.SerializeObject(lsCards), Encoding.UTF8, "application/json");
                var responseTask = client.PostAsync("Card", content);
                responseTask.Wait();

                var result = responseTask.Result;
                //Checking the response is successful or not which is sent using HttpClient  
                if (result.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var readTask = result.Content.ReadAsAsync<IList<Cards>>();

                    readTask.Wait();

                    CardInfo = readTask.Result.ToList();

                }
                //returning the employee list to view  
                // return View(EmpInfo);
            }
            ViewData["currentview"] = "result";
            return View("Index", CardInfo);

            // return View();
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
