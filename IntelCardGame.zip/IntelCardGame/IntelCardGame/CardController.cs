﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using IntelCardGame.Model;
using System;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace IntelCardGame
{
    [Route("api/[controller]")]
    [ApiController]
    public class CardController : ControllerBase
    {
        // GET: api/<CardController>
        [HttpGet]
        public List<Cards> GetCards()
        {


            List<Cards> ls = new List<Cards>() {
                 new Cards {  id=1,value="4T",color="#0275d8"},
                  new Cards {  id=2,value="2T" ,color="#5cb85c"},
                   new Cards {  id=3,value="ST", color="#f0ad4e"},
                    new Cards {  id=4,value="PT",color="#f0ad4e"},
                    new Cards {  id=5,value="RT",color="#d9534f"},
                     new Cards {  id=6,value="2D",color="#f0ad4e"},
                  new Cards {  id=7,value="3D",color="#f0ad4e"},
                   new Cards {  id=8,value="JS",color="#d9534f"},
                    new Cards {  id=9,value="4C",color="#f0ad4e"},
                    new Cards {  id=10,value="2Q",color="#d9534f"},
                      new Cards {  id=11,value="2D",color="#f0ad4e"},
                  new Cards {  id=12,value="JD",color="#f0ad4e"},
                   new Cards {  id=13,value="JS",color="#f0ad4e"},
                    new Cards {  id=14,value="KD",color="#f0ad4e"},
                    new Cards {  id=15,value="QD",color="#f0ad4e"},
                     new Cards {  id=16,value="AC",color="#f0ad4e"}
                    };

            var randomList = GetRandomElements(ls, 8);



            return randomList;

        }
        /// <summary>
        /// Get Random number on shuffle
        /// </summary>
        /// <typeparam name="t"></typeparam>
        /// <param name="list"></param>
        /// <param name="elementsCount"></param>
        /// <returns></returns>
        public static List<t> GetRandomElements<t>(IEnumerable<t> list, int elementsCount)
        {
            return list.OrderBy(x => Guid.NewGuid()).Take(elementsCount).ToList();
        }

        /// <summary>
        /// Assign id to perform sorting
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        private IList<Cards> setIndexvalue(List<Cards> list)
        {
            IList<Cards> pr = new List<Cards>() {
                 new Cards {  id=1,value="4T"},
                  new Cards {  id=2,value="2T"},
                   new Cards {  id=3,value="ST"},
                    new Cards {  id=3,value="PT"},
                    new Cards {  id=3,value="RT"}
                    };
            List<Cards> crd = new List<Cards>();
            foreach (Cards s in list)
            {
                var id = pr.Where(x => x.value == s.value).FirstOrDefault() != null ? pr.Where(x => x.value == s.value).FirstOrDefault().id: getid(s.value);
                Cards c = new Cards();
                c.id = id;
                c.value = s.value;
                c.color = s.color;
                crd.Add(c);
            }
            return crd;
        }

        /// <summary>
        /// assign unique id
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        private int getid(string s)
        {
            var s1 = s.Last();
            if (s1 == 'D')
            { return 6; }
            if (s1 == 'S')
            { return 7; }
            if (s1 == 'C')
            { return 8; }
            if (s1 == 'H')
            { return 9; }
            else
            {
                return 10;
            }
        }



        // POST api/<CardController>
        [HttpPost]
        public List<Cards> Post([FromBody]List<Cards> list)
        {
            var card = setIndexvalue(list);

            var SortedItems = card.OrderBy(x => x.id);

            return SortedItems.ToList();
        }

     
    }
}
